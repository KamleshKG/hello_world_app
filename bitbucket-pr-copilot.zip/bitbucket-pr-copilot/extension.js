const vscode = require('vscode');
const fetch = require('node-fetch');
const simpleGit = require('simple-git');

// Hardcoded credentials for POC
const WORKSPACE = 'myworkspace_poc';
const REPO = 'myrepo_poc';
const BASE_BRANCH = 'main';

// Use the workspace folder explicitly
const workspaceFolders = vscode.workspace.workspaceFolders;
if (!workspaceFolders) {
    vscode.window.showErrorMessage('Open a folder in VS Code with your Git repo!');
    return;
}
const repoPath = workspaceFolders[0].uri.fsPath;
const git = simpleGit(repoPath);

function activate(context) {

    // -------------------------------
    // 1. Test Git Connection
    // -------------------------------
    context.subscriptions.push(
        vscode.commands.registerCommand('bitbucketPRCopilot.testGit', async () => {
            try {
                const status = await git.status();
                vscode.window.showInformationMessage(`Current branch: ${status.current}`);
            } catch (err) {
                vscode.window.showErrorMessage(`Git error: ${err.message}`);
            }
        })
    );

    // -------------------------------
    // 2. Post AI Suggestions (Simplified)
    // -------------------------------
    context.subscriptions.push(
        vscode.commands.registerCommand('bitbucketPRCopilot.postSuggestions', async () => {
            try {
                // Detect current branch and files
                const status = await git.status();
                const branch = status.current;
                const files = status.files.map(f => f.path);

                if (!files.length) {
                    vscode.window.showInformationMessage('No changed files to suggest.');
                    return;
                }

                // Find or create PR
                let prId = await findPRForBranch(branch);
                if (!prId) {
                    const confirm = await vscode.window.showInformationMessage(
                        `No PR found for ${branch}. Create PR to ${BASE_BRANCH}?`,
                        'Create PR',
                        'Cancel'
                    );
                    if (confirm === 'Create PR') {
                        const prObj = await createPullRequest(branch);
                        prId = prObj.id;
                        vscode.window.showInformationMessage(`Created PR #${prId}.`);
                    } else return;
                }

                // Post suggestions for each file
                for (const file of files) {
                    const suggestion = `🔬 **POC Suggestion for ${file}:**\n- Review logic and edge cases\n- Add unit tests\n- Check performance impact`;
                    const line = await getFirstChangedLine(file);
                    
                    if (line) {
                        await postInlinePRComment(prId, file, line, suggestion);
                    } else {
                        await postPRComment(prId, file, suggestion);
                    }
                    vscode.window.showInformationMessage(`✅ Posted suggestion for ${file}`);
                }

                vscode.window.showInformationMessage(`🎉 All suggestions posted to PR #${prId}`);

            } catch (err) {
                vscode.window.showErrorMessage(`❌ Error: ${err.message}`);
            }
        })
    );

    // -------------------------------
    // 3. Post Highlighted Selection
    // -------------------------------
    context.subscriptions.push(
        vscode.commands.registerCommand('bitbucketPRCopilot.postSelection', async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) return vscode.window.showWarningMessage('No active editor.');

            const selection = editor.selection;
            const selectedText = editor.document.getText(selection);
            if (!selectedText) return vscode.window.showWarningMessage('No text selected.');

            try {
                const status = await git.status();
                const branch = status.current;
                
                let prId = await findPRForBranch(branch);
                if (!prId) {
                    const prObj = await createPullRequest(branch);
                    prId = prObj.id;
                    vscode.window.showInformationMessage(`Created PR #${prId}.`);
                }

                const filePath = vscode.workspace.asRelativePath(editor.document.fileName);
                const line = selection.start.line + 1;
                
                await postInlinePRComment(prId, filePath, line, selectedText);
                vscode.window.showInformationMessage(`📝 Posted selection to PR #${prId}`);

            } catch (err) {
                vscode.window.showErrorMessage(`❌ Error: ${err.message}`);
            }
        })
    );
}

// -------------------------------
// Simplified Bitbucket API helpers
// -------------------------------
function getAuthHeader() {
    return 'Basic ' + Buffer.from(`${BITBUCKET_EMAIL}:${BITBUCKET_TOKEN}`).toString('base64');
}

async function findPRForBranch(branch) {
    const url = `https://api.bitbucket.org/2.0/repositories/${WORKSPACE}/${REPO}/pullrequests?state=OPEN&source.branch.name=${branch}`;
    const res = await fetch(url, { 
        headers: { 
            'Authorization': getAuthHeader(),
            'Content-Type': 'application/json'
        } 
    });
    if (!res.ok) throw new Error(`API Error: ${res.status}`);
    const data = await res.json();
    return data.values?.[0]?.id || null;
}

async function createPullRequest(sourceBranch, title, description) {
    const url = `https://api.bitbucket.org/2.0/repositories/${WORKSPACE}/${REPO}/pullrequests`;
    const body = {
        title: title || `Auto PR: ${sourceBranch} → ${BASE_BRANCH}`,
        description: description || 'Automated PR created by Bitbucket PR Copilot POC.',
        source: { branch: { name: sourceBranch } },
        destination: { branch: { name: BASE_BRANCH } },
        close_source_branch: false
    };
    const res = await fetch(url, {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json', 
            'Authorization': getAuthHeader() 
        },
        body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(`Create PR failed: ${res.status} ${await res.text()}`);
    return await res.json();
}

async function postPRComment(prId, filePath, suggestion) {
    const url = `https://api.bitbucket.org/2.0/repositories/${WORKSPACE}/${REPO}/pullrequests/${prId}/comments`;
    const payload = { content: { raw: suggestion } };
    const res = await fetch(url, {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json', 
            'Authorization': getAuthHeader() 
        },
        body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`PR comment failed: ${res.status}`);
    return await res.json();
}

async function postInlinePRComment(prId, filePath, lineNumber, suggestion) {
    const url = `https://api.bitbucket.org/2.0/repositories/${WORKSPACE}/${REPO}/pullrequests/${prId}/comments`;
    const payload = { 
        content: { raw: suggestion }, 
        inline: { path: filePath, to: lineNumber } 
    };
    const res = await fetch(url, {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json', 
            'Authorization': getAuthHeader() 
        },
        body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(`Inline comment failed: ${res.status}`);
    return await res.json();
}

// Get first changed line in file
async function getFirstChangedLine(filePath) {
    try {
        const diffRaw = await git.raw(['diff', `${BASE_BRANCH}..HEAD`, '--', filePath]);
        const m = diffRaw.match(/\+\s*([0-9]+)(?:,([0-9]+))?/);
        return m ? parseInt(m[1], 10) : null;
    } catch (err) {
        return null;
    }
}

function deactivate() {}

module.exports = { activate, deactivate };