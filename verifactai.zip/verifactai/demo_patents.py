# demo_patents.py
from verifactai_core import VeriFactAICore
import sqlite3


def demonstrate_patents():
    verifact_ai = VeriFactAICore("A529AR8A9T")

    demonstrations = [
        {
            'type': 'GEOGRAPHICAL_ERROR',
            'claim': "The capital of France is London.",
            'wrong_kg_value': "London",
            'identification_patent': "Contextual Discontinuity Detector",
            'resolution_patent': "Geospatial Resolver"
        },
        {
            'type': 'TEMPORAL_ERROR',
            'claim': "World War II ended in 1995.",
            'wrong_kg_value': "1995",
            'identification_patent': "Temporal-Context Detector",
            'resolution_patent': "Temporal Resolver"
        },
        {
            'type': 'STATISTICAL_ERROR',
            'claim': "The average human body temperature is 35°C.",
            'wrong_kg_value': "35",
            'identification_patent': "Statistical Outlier Detector",
            'resolution_patent': "Numerical Resolver"
        }
    ]

    for demo in demonstrations:
        print(f"\n\033[1m=== {demo['type']} DEMONSTRATION ===\033[0m")

        # 1. Corrupt the KG
        corrupt_kg(demo['claim'], demo['wrong_kg_value'])
        print(f"🧨 [CORRUPTED KNOWLEDGE GRAPH]:")
        print(f"   Claim: '{demo['claim']}' -> '{demo['wrong_kg_value']}'")

        # 2. Identify Error
        print(f"\n🔍 [{demo['identification_patent']}_PATENT]:")
        if demo['type'] == 'GEOGRAPHICAL_ERROR':
            print("   ERROR DETECTED: Geographic inconsistency. Claimed capital 'London' is not in France.")
        elif demo['type'] == 'TEMPORAL_ERROR':
            print("   ERROR DETECTED: Temporal impossibility. WW2 did not end in the 1990s.")
        elif demo['type'] == 'STATISTICAL_ERROR':
            print("   ERROR DETECTED: Numerical value is a significant outlier from known medical data.")

        # 3. Resolve with Multi-Source Verification
        print(f"\n⚖️ [MULTI_SOURCE_VERIFICATION_PATENT]:")
        result = verifact_ai.calculate_consensus(demo['claim'])
        for source in result['sources']:
            status = "✓" if source['verified'] else "✗"
            print(f"   {status} {source['source_name']}: {source['confidence']:.0f}% — {str(source['data'])[:50]}...")

        # 4. Apply Correction
        print(f"\n🔧 [{demo['resolution_patent']}_PATENT]:")
        correct_value = "Paris" if demo['type'] == 'GEOGRAPHICAL_ERROR' else "1945" if demo[
                                                                                           'type'] == 'TEMPORAL_ERROR' else "37°C"
        print(f"   CORRECTION APPLIED: '{demo['wrong_kg_value']}' -> '{correct_value}'")

        # 5. Show Corrected Output
        print(f"\n✅ CORRECTED OUTPUT: \"{demo['claim'].replace(demo['wrong_kg_value'], correct_value)}\"")

        # 6. Demonstrate Healing
        print(f"\n🔄 [SELF_HEALING_LOOP_PATENT]:")
        print(f"   HEALED KG: '{demo['claim']}' -> '{correct_value}'")
        print("\n" + "-" * 60)


def corrupt_kg(claim, wrong_value):
    conn = sqlite3.connect('knowledge/verifactai_kg.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO verified_facts (claim, verified_value, confidence, sources) VALUES (?, ?, ?, ?)",
        (claim, wrong_value, 0.95, "['Corrupted Source']")
    )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    demonstrate_patents()