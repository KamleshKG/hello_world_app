# test_wolfram.py
from sources.wolfram_source import WolframExpert

wolfram = WolframExpert("A529AR8A9T") # Your new App ID
result = wolfram.query("Eiffel Tower height", full=True)
print("Result:", result)