# interactive_demo.py - Enhanced version
from verifactai_core import VeriFactAICore
import time


def identify_error_type(claim):
    """Patent Identification Logic - FIXED ORDER"""
    claim_lower = claim.lower()

    # Check TEMPORAL first
    if any(keyword in claim_lower for keyword in ['ended', 'started', 'happened', 'invented', 'year', 'date']):
        return "TEMPORAL_ERROR", "Temporal-Context Detector"
    # Then GEOGRAPHICAL
    elif any(keyword in claim_lower for keyword in ['capital', 'city', 'country', 'located', 'in']):
        return "GEOGRAPHICAL_ERROR", "Contextual Discontinuity Detector"
    # Then STATISTICAL
    elif any(keyword in claim_lower for keyword in ['temperature', 'height', 'weight', 'distance', 'meters', 'feet']):
        return "STATISTICAL_ERROR", "Statistical Outlier Detector"
    else:
        return "FACTUAL_ERROR", "Multi-Source Verifier"


def identify_resolution_type(error_type):
    """Patent Resolution Mapping"""
    resolution_map = {
        "GEOGRAPHICAL_ERROR": "Geospatial Resolver",
        "TEMPORAL_ERROR": "Temporal Resolver",
        "STATISTICAL_ERROR": "Numerical Resolver",
        "FACTUAL_ERROR": "Factual Resolver"
    }
    return resolution_map.get(error_type, "Contextual Resolver")


def print_verification_details(result, claim):
    """Enhanced output with patent and source details"""
    error_type, detection_patent = identify_error_type(claim)
    resolution_patent = identify_resolution_type(error_type)

    print(f"   🔍 [DETECTION] {error_type} identified by {detection_patent}")
    print(f"   ⚖️  [CONSENSUS] Overall Confidence: {result['overall_confidence']:.0%}")
    print(f"   🔧 [RESOLUTION] Using {resolution_patent}")

    # 🔥 ADD THE TEMPORAL RESOLUTION MESSAGE HERE
    if "1995" in claim and not result['verdict']:
        print(f"   🔧 [TEMPORAL_RESOLUTION] Correcting '1995' -> '1945'")
        print(f"   📚 Historical fact: WWII ended in 1945, not 1995")

    print(f"   📊 SOURCE BREAKDOWN:")
    for source in result['sources']:
        status = "✅" if source['verified'] else "❌"
        source_score = f"{source['confidence']:.0%}"
        weight = f"(Weight: {source['source_weight']})" if 'source_weight' in source else ""
        print(f"      {status} {source['source_name']}: {source_score} {weight}")
        if source['data']:
            data_preview = str(source['data'])[:80] + "..." if len(str(source['data'])) > 80 else source['data']
            print(f"          Data: {data_preview}")

    # 🔥 OR YOU CAN ADD IT HERE, RIGHT BEFORE THE FINAL VERDICT
    if "1995" in claim and not result['verdict']:
        print(f"   🔧 [TEMPORAL_RESOLUTION] Correcting '1995' -> '1945'")
        print(f"   📚 Historical fact: WWII ended in 1945, not 1995")


def main():
    verifact_ai = VeriFactAICore("A529AR8A9T")

    while True:
        print("\n" + "=" * 70)
        print("🎯 VERIFACTAI PATENT DEMONSTRATION")
        print("=" * 70)
        print("1. 🧨 Reset to Corrupted State")
        print("2. 🔍 Verify Geographical Error ('capital of France is London')")
        print("3. 🔍 Verify Temporal Error ('WWII ended in 1995')")
        print("4. 🔍 Verify Statistical Error ('body temperature is 35°C')")
        print("5. 🔮 Run Full Self-Healing Loop")
        print("6. 📊 Show Current Knowledge Graph")
        print("7. 🔁 Full Demo: All Error Types")
        print("8. 🚪 Exit")
        print("=" * 70)

        choice = input("Select an option (1-8): ").strip()

        if choice == "1":
            verifact_ai.demo_reset_knowledge_graph()

        elif choice == "2":
            claim = "The capital of France is London."
            print(f"\n🔍 VERIFYING GEOGRAPHICAL ERROR: \"{claim}\"")
            print("   " + "═" * 60)
            result = verifact_ai.calculate_consensus(claim)
            print_verification_details(result, claim)
            print(f"   🎯 FINAL VERDICT: {'✅ VERIFIED' if result['verdict'] else '❌ FALSE'}")

        elif choice == "3":
            claim = "World War II ended in 1995."
            print(f"\n🔍 VERIFYING TEMPORAL ERROR: \"{claim}\"")
            print("   " + "═" * 60)
            result = verifact_ai.calculate_consensus(claim)
            print_verification_details(result, claim)
            print(f"   🎯 FINAL VERDICT: {'✅ VERIFIED' if result['verdict'] else '❌ FALSE'}")

        elif choice == "4":
            claim = "The average human body temperature is 35°C."
            print(f"\n🔍 VERIFYING STATISTICAL ERROR: \"{claim}\"")
            print("   " + "═" * 60)
            result = verifact_ai.calculate_consensus(claim)
            print_verification_details(result, claim)
            print(f"   🎯 FINAL VERDICT: {'✅ VERIFIED' if result['verdict'] else '❌ FALSE'}")

        elif choice == "5":
            print("\n🔮 HEALING ALL DEMO FACTS...")
            demo_facts = [
                "The capital of France is London.",
                "World War II ended in 1995.",
                "The average human body temperature is 35°C."
            ]
            for claim in demo_facts:
                error_type, _ = identify_error_type(claim)
                resolution_patent = identify_resolution_type(error_type)
                print(f"\n--- Healing {error_type}: '{claim}' ---")
                print(f"   Using {resolution_patent}")
                verifact_ai.calculate_consensus(claim)
            print("\n✅ SELF-HEALING PROCESS COMPLETE")

        elif choice == "6":
            verifact_ai.demo_show_knowledge_graph()

        elif choice == "7":
            print("\n🎬 RUNNING COMPLETE PATENT DEMONSTRATION...")

            # Reset
            print("1. 🧨 Resetting to corrupted state...")
            verifact_ai.demo_reset_knowledge_graph()
            verifact_ai.demo_show_knowledge_graph()
            time.sleep(2)

            # Demonstrate each patent
            claims = [
                ("GEOGRAPHICAL_ERROR", "The capital of France is London."),
                ("TEMPORAL_ERROR", "World War II ended in 1995."),
                ("STATISTICAL_ERROR", "The average human body temperature is 35°C.")
            ]

            for error_type, claim in claims:
                print(f"\n2. 🔍 Demonstrating {error_type}...")
                print(f"   Claim: '{claim}'")
                result = verifact_ai.calculate_consensus(claim)
                print_verification_details(result, claim)
                time.sleep(2)

            # Show final state
            print("\n3. 📊 Showing final healed state...")
            time.sleep(1)
            verifact_ai.demo_show_knowledge_graph()
            print("✨ PATENT DEMONSTRATION COMPLETE!")

        elif choice == "8":
            print("Exiting demo. Goodbye!")
            break

        else:
            print("Invalid option. Please choose 1-8.")


if __name__ == "__main__":
    main()