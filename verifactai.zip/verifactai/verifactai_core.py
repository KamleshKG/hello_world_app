import sqlite3
from datetime import datetime
from sources.wolfram_source import WolframExpert
from sources.wikipedia_source import WikipediaSource


class VeriFactAICore:
    """
    Core VeriFactAI engine with weighted consensus and self-healing KG.
    This represents multiple patentable components.
    """

    def __init__(self, wolfram_app_id):
        self.sources = []
        self.source_weights = {
            'WolframAlpha': 0.9,  # High weight for numerical/factual data
            'Wikipedia': 0.7,  # Medium weight for general knowledge
        }
        self._init_knowledge_graph()

        # Add sources
        self.add_source(WolframExpert(wolfram_app_id))
        self.add_source(WikipediaSource())

    def _init_knowledge_graph(self):
        """Initialize the self-healing knowledge graph database"""
        self.kg_conn = sqlite3.connect('knowledge/verifactai_kg.db')
        self.kg_conn.execute("""
            CREATE TABLE IF NOT EXISTS verified_facts (
                id INTEGER PRIMARY KEY,
                claim TEXT UNIQUE,
                verified_value TEXT,
                confidence REAL,
                sources TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def add_source(self, source):
        self.sources.append(source)

    def calculate_consensus(self, claim: str) -> dict:
        """Patent-pending weighted consensus algorithm"""
        source_results = []
        weighted_sum = 0.0  # FIX: Initialize before use
        total_weight = 0.0  # FIX: Initialize before use

        for source in self.sources:
            source_result = source.verify_claim(claim)
            weight = self.source_weights.get(source.source_name, 0.5)

            # Store the weight for display purposes
            source_result['source_weight'] = weight

            # Only count the source if it successfully verified the claim
            if source_result['verified']:
                source_result['weighted_confidence'] = source_result['confidence'] * weight
                weighted_sum += source_result['weighted_confidence']
                total_weight += weight
            else:
                source_result['weighted_confidence'] = 0
                source_result['data'] = source_result.get('data', 'No data')  # Ensure data exists

            source_results.append(source_result)

        # Calculate weighted average confidence ONLY if we have successful sources
        if total_weight > 0:
            overall_confidence = weighted_sum / total_weight
        else:
            overall_confidence = 0

        # Determine verdict (configurable threshold)
        is_verified = overall_confidence >= 0.65

        # Self-healing: Add to KG if high confidence
        if overall_confidence > 0.65:
            print(f"🐛 [HEALING] High confidence ({overall_confidence:.2f}), triggering self-healing for: '{claim}'")
            self._add_to_knowledge_graph(claim, source_results)
        else:
            print(f"🐛 [HEALING] Confidence too low ({overall_confidence:.2f}), skipping KG update for: '{claim}'")

        return {
            'claim': claim,
            'verdict': is_verified,
            'overall_confidence': overall_confidence,
            'sources': source_results
        }

    def _add_to_knowledge_graph(self, claim, source_results):
        """Self-healing loop: Add verified facts to the KG"""
        try:
            print(f"🐛 [HEALING] Attempting to update KG for: '{claim}'")

            cursor = self.kg_conn.cursor()

            # Extract verified data from successful sources
            verified_sources = [s for s in source_results if s['verified']]
            if not verified_sources:
                print("🐛 [HEALING] No verified sources, skipping KG update.")
                return

            source_names = [s['source_name'] for s in verified_sources]
            verified_value = str([s['data'] for s in verified_sources])
            confidence_val = max(s['confidence'] for s in verified_sources)

            print(f"🐛 [HEALING] New value to store: {verified_value}")

            # Use UPDATE OR INSERT approach
            cursor.execute(
                """UPDATE verified_facts 
                   SET verified_value = ?, confidence = ?, sources = ?, timestamp = CURRENT_TIMESTAMP 
                   WHERE claim = ?""",
                (verified_value, confidence_val, str(source_names), claim)
            )

            if cursor.rowcount == 0:
                print("🐛 [HEALING] No existing row found, inserting new record.")
                cursor.execute(
                    """INSERT INTO verified_facts (claim, verified_value, confidence, sources) 
                       VALUES (?, ?, ?, ?)""",
                    (claim, verified_value, confidence_val, str(source_names))
                )
            else:
                print(f"🐛 [HEALING] Updated existing record. Rows affected: {cursor.rowcount}")

            self.kg_conn.commit()
            print(f"✅ [HEALING] KG successfully updated for: {claim}")

        except sqlite3.Error as e:
            print(f"❌ [HEALING] Database error: {e}")

    def query_knowledge_graph(self, claim):
        """Check the self-healing KG first"""
        cursor = self.kg_conn.cursor()
        cursor.execute(
            "SELECT verified_value, confidence FROM verified_facts WHERE claim LIKE ?",
            (f'%{claim}%',)
        )
        return cursor.fetchone()

    # Add these methods to the VeriFactAICore class in verifactai_core.py

    def demo_reset_knowledge_graph(self):
        """Patent Demo: Reset the KG to a known corrupted state for demonstrations."""
        print("🧨 [DEMO MODE] RESETTING KNOWLEDGE GRAPH TO CORRUPTED STATE...")
        try:
            cursor = self.kg_conn.cursor()

            # First, clear all existing demo facts to avoid duplicates
            cursor.execute(
                "DELETE FROM verified_facts WHERE claim LIKE '%France%' OR claim LIKE '%World War II%' OR claim LIKE '%body temperature%'")

            # Define the demo facts we want to corrupt
            demo_facts = {
                "The capital of France is London.": "London",
                "World War II ended in 1995.": "1995",
                "The average human body temperature is 35°C.": "35"
            }

            for claim, wrong_value in demo_facts.items():
                cursor.execute(
                    """INSERT INTO verified_facts 
                       (claim, verified_value, confidence, sources) 
                       VALUES (?, ?, ?, ?)""",
                    (claim, wrong_value, 0.95, "['Corrupted Source']")
                )
            self.kg_conn.commit()
            print("✅ [DEMO MODE] Knowledge Graph reset to corrupted state. Ready for demonstration.")

        except sqlite3.Error as e:
            print(f"❌ [DEMO MODE] Failed to reset KG: {e}")

    def demo_show_knowledge_graph(self):
        """Display the current state of demo facts in the KG."""
        print("\n📋 CURRENT KNOWLEDGE GRAPH STATE")
        print("-" * 50)

        demo_facts = [
            "The capital of France is London.",
            "World War II ended in 1995.",
            "The average human body temperature is 35°C."
        ]

        cursor = self.kg_conn.cursor()
        for claim in demo_facts:
            cursor.execute("SELECT verified_value, confidence FROM verified_facts WHERE claim = ?", (claim,))
            kg_result = cursor.fetchone()

            if kg_result:
                # Extract just the first (most relevant) piece of evidence for clean display
                try:
                    # The stored value is a string representation of a list
                    import ast
                    data_list = ast.literal_eval(kg_result[0])
                    if isinstance(data_list, list) and len(data_list) > 0:
                        clean_value = data_list[0]  # Take first item
                        if isinstance(clean_value, list) and len(clean_value) > 0:
                            clean_value = clean_value[0]  # Handle nested lists
                    else:
                        clean_value = kg_result[0][:100] + "..."  # Truncate if not list
                except:
                    clean_value = kg_result[0][:100] + "..."  # Fallback

                status = "✅" if "Paris" in str(kg_result[0]) or "1945" in str(kg_result[0]) or "37" in str(
                    kg_result[0]) else "❌"
                print(f"{status} \"{claim}\"")
                print(f"   → {clean_value} (Confidence: {kg_result[1]:.0%})")
            else:
                print(f"❓ \"{claim}\"")
                print(f"   → No entry in knowledge graph")
            print()