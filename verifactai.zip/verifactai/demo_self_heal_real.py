# demo_self_heal_real.py
from verifactai_core import VeriFactAICore
import sqlite3


def demonstrate_real_healing():
    print("🔮 DEMONSTRATING TRUE SELF-HEALING OVER TIME")
    print("=============================================")

    verifact_ai = VeriFactAICore("A529AR8A9T")
    claim = "The capital of France is London."

    # --- ROUND 1: First encounter (KG is empty or wrong) ---
    print("\n1. 🧪 FIRST ENCOUNTER: System finds error in LLM output.")
    kg_result = verifact_ai.query_knowledge_graph(claim)
    print(f"   Knowledge Graph: {kg_result[0] if kg_result else 'No entry found'}")

    # This will correct the KG
    result = verifact_ai.calculate_consensus(claim)
    print(f"   Verdict: {'✅ VERIFIED' if result['verdict'] else '❌ FALSE'}")
    print(f"   Action: Self-Healing Loop triggered. KG updated with correct fact.")

    # --- ROUND 2: Second encounter (KG is now healed) ---
    print("\n2. 🔁 SECOND ENCOUNTER: Same query from a different user.")
    kg_result_healed = verifact_ai.query_knowledge_graph(claim)
    print(f"   Knowledge Graph: {kg_result_healed[0] if kg_result_healed else 'No entry found'}")

    if kg_result_healed and "Paris" in kg_result_healed[0]:
        print("   ✅ RESULT: User gets correct answer INSTANTLY from KG. No API calls needed.")
        print("   💰 SAVINGS: Faster response, zero API cost, guaranteed accuracy.")
    else:
        print("   ❌ ERROR: The self-healing loop did not work correctly.")


if __name__ == "__main__":
    demonstrate_real_healing()