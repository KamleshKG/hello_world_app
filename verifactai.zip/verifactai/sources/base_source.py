from abc import ABC, abstractmethod

class VerificationSource(ABC):
    """Abstract base class for all verification sources."""

    @abstractmethod
    def verify_claim(self, claim: str) -> dict:
        print(f"🐛 DEBUG: verify_claim called with: '{claim}'")
        reformulated_query = self._reformulate_query_for_wolfram(claim)
        print(f"🐛 DEBUG: Reformulated query: '{reformulated_query}'")

        response = self.query(reformulated_query, full=True)
        print(f"🐛 DEBUG: Query successful: {response.get('success')}")

        if not response.get("success"):
            # Even if Wolfram fails, we can still return a structured response
            return {
                "verified": False,
                "confidence": 0.3,  # Low confidence for failed queries
                "data": "Could not process this factual statement",
                "source_name": self.source_name
            }

        verification_data = []
        # Look for different types of answer pods
        for pod in response["data"]:
            if pod["title"] in ["Result", "Answer", "Value", "Date", "Definition", "Basic information"]:
                verification_data.extend(subpod["text"] for subpod in pod["subpods"])

        print(f"🐛 DEBUG: Found verification data: {verification_data}")

        if verification_data:
            confidence = 0.8  # High confidence for successful answers
            return {
                "verified": True,
                "confidence": confidence,
                "data": verification_data,
                "source_name": self.source_name
            }
        else:
            # Even with success: True, we might not have found direct answers
            return {
                "verified": False,
                "confidence": 0.4,  # Medium confidence - Wolfram responded but no direct answer
                "data": "No direct answer found in Wolfram response",
                "source_name": self.source_name
            }