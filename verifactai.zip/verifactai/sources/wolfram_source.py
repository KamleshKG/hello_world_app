import requests
import json
import sqlite3
from datetime import datetime
import os
from functools import lru_cache
from .base_source import VerificationSource


class WolframExpert(VerificationSource):
    """
    Complete Wolfram Alpha integration with caching.
    Now implements the VerificationSource interface.
    """

    def __init__(self, app_id, cache_db="knowledge/wolfram_cache.db"):
        self.app_id = app_id
        self.base_url = "https://api.wolframalpha.com/"
        self.source_name = "WolframAlpha"
        self._init_cache_db(cache_db)

    def _init_cache_db(self, db_path):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                query TEXT PRIMARY KEY,
                response TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    @lru_cache(maxsize=1000)
    def _memory_cache(self, query):
        cursor = self.conn.cursor()
        cursor.execute("SELECT response FROM cache WHERE query=?", (query,))
        if row := cursor.fetchone():
            return json.loads(row[0])
        return None

    def _store_cache(self, query, response):
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO cache VALUES (?, ?, ?)",
            (query, json.dumps(response), datetime.now())
        )
        self.conn.commit()
        self._memory_cache.cache_clear()

    def query(self, question, full=False, force_fresh=False):
        # ... (cache checking code remains the same) ...

        endpoint = "v2/query" if full else "v1/result"
        # CORRECT PARAMS FOR FULL RESULTS API:
        params = {
            "input": question,  # Key is "input" for v2/query
            "appid": self.app_id,
            "output": "json" if full else None  # "output" is for v2/query
        }
        # For simple queries (v1/result), the key is "i", so we need an if-else:
        if not full:
            params = {
                "i": question,  # Key is "i" for v1/result
                "appid": self.app_id,
                # "output" is not a standard parameter for v1/result
            }

        try:
            print(f"🐛 DEBUG: Sending request to {endpoint} with params: {params}")  # DEBUG LINE
            response = requests.get(
                f"{self.base_url}{endpoint}",
                params={k: v for k, v in params.items() if v is not None},
                timeout=15
            )
            print(f"🐛 DEBUG: Response Status: {response.status_code}")  # DEBUG LINE
            response.raise_for_status()

            result = self._parse_response(response, full)
            self._store_cache(question, result)
            return result

        except requests.exceptions.RequestException as e:
            print(f"🐛 CRITICAL Wolfram API Error: {e}")  # DEBUG LINE
            if hasattr(e.response, 'text'):
                print(f"🐛 ERROR RESPONSE BODY: {e.response.text}")  # DEBUG LINE
            return {"success": False, "error": f"Request failed: {e}"}

    def _parse_response(self, response, full):
        if full:
            try:
                data = response.json()
                return {
                    "success": data.get("queryresult", {}).get("success", False),
                    "type": "full",
                    "data": self._extract_pods(data)
                }
            except json.JSONDecodeError:
                return {"success": False, "error": "Invalid JSON response"}
        else:
            return {"success": True, "type": "simple", "data": response.text.strip()}

    def _extract_pods(self, data):
        pods = []
        for pod in data.get("queryresult", {}).get("pods", []):
            current_pod = {
                "title": pod.get("title", ""),
                "subpods": []
            }
            for subpod in pod.get("subpods", []):
                current_pod["subpods"].append({
                    "title": subpod.get("title", ""),
                    "text": subpod.get("plaintext", "")
                })
            pods.append(current_pod)
        return pods

    # --- The REQUIRED VerificationSource method ---
    def verify_claim(self, claim: str) -> dict:
        print(f"🐛 DEBUG: verify_claim called with: '{claim}'")
        reformulated_query = self._reformulate_query_for_wolfram(claim)
        print(f"🐛 DEBUG: Reformulated query: '{reformulated_query}'")

        response = self.query(reformulated_query, full=True)
        # Just log success, not the huge data blob
        print(f"🐛 DEBUG: Query successful: {response.get('success')}")

        if not response.get("success"):
            return {
                "verified": False,
                "confidence": 0.0,
                "data": response.get("error", "Could not process query"),
                "source_name": self.source_name
            }

        verification_data = []
        # Improved pod matching: Look for pods that contain actual answers
        for pod in response["data"]:
            # Check if this pod looks like it contains a direct answer to a factual query
            if pod["title"] in ["Result", "Basic information", "Definition", "Value", "Capital"]:
                verification_data.extend(subpod["text"] for subpod in pod["subpods"])

        print(f"🐛 DEBUG: Found verification data: {verification_data}")  # Add this line

        if verification_data:
            # MAJOR CHANGE: Base confidence on finding a relevant pod, not the number of subpods.
            # If we found a pod with a direct answer, confidence is high.
            confidence = 0.9
            return {
                "verified": True,
                "confidence": confidence,
                "data": verification_data,
                "source_name": self.source_name
            }
        else:
            # Even if no direct answer, Wolfram responded. Give it a low confidence.
            return {
                "verified": False,
                "confidence": 0.3,  # Increased from 0.1
                "data": "No direct answer found in Wolfram response",
                "source_name": self.source_name
            }

    def _reformulate_query_for_wolfram(self, claim: str) -> str:
        """
        Patent-pending method to convert factual claims into WolframAlpha queries.
        Now with much smarter reformulation for different query types.
        """
        # Convert statement into a question Wolfram can understand
        claim_lower = claim.lower()

        # TEMPORAL queries: "X happened in YYYY" -> "X date"
        if any(keyword in claim_lower for keyword in ['ended in', 'started in', 'happened in', 'invented in']):
            if "world war ii" in claim_lower or "ww2" in claim_lower:
                return "World War II end date"
            elif "world war i" in claim_lower or "ww1" in claim_lower:
                return "World War I end date"
            else:
                # Generic pattern: "Event happened in YEAR" -> "Event date"
                event = claim.split(" in ")[0]
                return f"{event} date"

        # GEOGRAPHICAL queries: "Capital of X is Y" -> "capital of X"
        elif "capital of" in claim_lower:
            country = claim_lower.split("capital of ")[1].split(" is ")[0]
            return f"capital of {country}"

        # STATISTICAL queries: "X is Y units" -> "X"
        elif any(unit in claim_lower for unit in ['°c', '°f', 'meters', 'feet', 'km', 'miles', 'kg', 'pounds']):
            subject = claim.split(" is ")[0]
            return subject

        # PERSON queries: "X invented Y" -> "inventor of Y"
        elif "invented" in claim_lower or "created" in claim_lower:
            if "python" in claim_lower:
                return "Python creator"
            else:
                invention = claim_lower.split("invented ")[1] if "invented" in claim_lower else \
                claim_lower.split("created ")[1]
                return f"inventor of {invention}"

        # Fallback: Direct question format
        else:
            # Convert "X is Y" to "what is X?"
            if " is " in claim_lower:
                subject = claim.split(" is ")[0]
                return f"what is {subject}"
            return claim