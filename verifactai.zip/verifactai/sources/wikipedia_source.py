import wikipedia
from .base_source import VerificationSource


class WikipediaSource(VerificationSource):
    """Simplified Wikipedia verification source."""

    def __init__(self):
        self.source_name = "Wikipedia"
        wikipedia.set_lang("en")

    def verify_claim(self, claim: str) -> dict:
        try:
            summary = wikipedia.summary(claim, sentences=1, auto_suggest=True)
            return {
                "verified": True,
                "confidence": 0.7,  # Medium confidence
                "data": summary,
                "source_name": self.source_name
            }
        except wikipedia.exceptions.PageError:
            return {
                "verified": False,
                "confidence": 0.1,
                "data": "Wikipedia page not found",
                "source_name": self.source_name
            }
        except wikipedia.exceptions.DisambiguationError as e:
            return {
                "verified": False,
                "confidence": 0.3,
                "data": f"Disambiguation: {e.options[:3]}",
                "source_name": self.source_name
            }
        except Exception as e:
            return {
                "verified": False,
                "confidence": 0.0,
                "data": f"Error: {str(e)}",
                "source_name": self.source_name
            }