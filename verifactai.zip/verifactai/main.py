from verifactai_core import VeriFactAICore


def main():
    print("🚀 Initializing VeriFactAI Engine...")

    # Initialize with your Wolfram App ID
    verifact_ai = VeriFactAICore("A529AR8A9T")  # Replace with your actual App ID

    test_claims = [
        "The Eiffel Tower is 1000 feet tall",
        "The Eiffel Tower is 330 meters tall",
        "Python was created by Guido van Rossum",
        "The capital of France is London",
        "The speed of light is 300,000 km/s"
    ]

    for claim in test_claims:
        print(f"\n{'=' * 60}")
        print(f"🔍 Verifying claim: '{claim}'")

        # Check KG first (progressive verification)
        if kg_result := verifact_ai.query_knowledge_graph(claim):
            print("✅ Found in Knowledge Graph (fast verification)")
            print(f"   Verified Value: {kg_result[0]}")
            print(f"   Confidence: {kg_result[1]:.2%}")
        else:
            # Full multi-source verification
            result = verifact_ai.calculate_consensus(claim)
            status = "✅ VERIFIED" if result['verdict'] else "❌ FALSE"
            print(f"{status} | Confidence: {result['overall_confidence']:.2%}")

            print("\n   Source Breakdown:")
            for source in result['sources']:
                verdict = "✓" if source['verified'] else "✗"
                print(f"   {verdict} {source['source_name']}: {source['confidence']:.2%} confidence")
                if source['data']:
                    print(f"      Data: {str(source['data'])[:100]}...")


if __name__ == "__main__":
    main()