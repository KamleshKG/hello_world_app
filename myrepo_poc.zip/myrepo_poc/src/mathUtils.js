// Simple math utility functions

function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

// TODO: implement multiply and divide
