// Dummy data processor

function processData(data) {
    // simulate processing
    return data.map(item => item.value * 2);
}

function filterValid(data) {
    return data.filter(item => item.isValid);
}

// TODO: add sorting function
