const { add, subtract } = require('../src/mathUtils');
const assert = require('assert');

assert.strictEqual(add(2,3), 5);
assert.strictEqual(subtract(5,2), 3);

// TODO: add tests for new functions
